-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 01-06-2017 a las 17:28:34
-- Versión del servidor: 5.7.18-0ubuntu0.16.04.1
-- Versión de PHP: 7.0.15-0ubuntu0.16.04.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `perro`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `infoDoggo`
--

CREATE TABLE `infoDoggo` (
  `idinfoDoggo` int(11) NOT NULL,
  `nombrePerro` varchar(50) NOT NULL,
  `tiopCola` varchar(50) NOT NULL,
  `tipoCabeza` varchar(50) NOT NULL,
  `tipoPelo` varchar(50) NOT NULL,
  `color` varchar(50) NOT NULL,
  `nombreRaza` varchar(45) NOT NULL,
  `tamanio` varchar(45) NOT NULL,
  `peso` double NOT NULL,
  `edad` varchar(45) DEFAULT NULL,
  `razon` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `infoDuenio`
--

CREATE TABLE `infoDuenio` (
  `idinfoDuenio` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT 'necesario para saber a quien pertenece el perro',
  `correo` varchar(60) DEFAULT 'correo para notificarle cosas',
  `telefono` int(11) DEFAULT NULL,
  `direccion` longtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `infoRazon`
--

CREATE TABLE `infoRazon` (
  `idrazon` int(11) NOT NULL,
  `consulta` varchar(45) DEFAULT NULL,
  `enfermedad` varchar(45) DEFAULT NULL,
  `vacuna` varchar(45) DEFAULT NULL,
  `desparasitacion` varchar(45) DEFAULT NULL,
  `operacion` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `informacion`
--

CREATE TABLE `informacion` (
  `idinformacion` int(11) NOT NULL,
  `raza` int(11) NOT NULL,
  `duenio` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `infoDoggo`
--
ALTER TABLE `infoDoggo`
  ADD PRIMARY KEY (`idinfoDoggo`),
  ADD KEY `infRazon_idx` (`razon`);

--
-- Indices de la tabla `infoDuenio`
--
ALTER TABLE `infoDuenio`
  ADD PRIMARY KEY (`idinfoDuenio`);

--
-- Indices de la tabla `infoRazon`
--
ALTER TABLE `infoRazon`
  ADD PRIMARY KEY (`idrazon`);

--
-- Indices de la tabla `informacion`
--
ALTER TABLE `informacion`
  ADD PRIMARY KEY (`idinformacion`),
  ADD KEY `infRaza_idx` (`raza`),
  ADD KEY `infDuenio_idx` (`duenio`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `infoDoggo`
--
ALTER TABLE `infoDoggo`
  MODIFY `idinfoDoggo` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `infoDuenio`
--
ALTER TABLE `infoDuenio`
  MODIFY `idinfoDuenio` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `infoRazon`
--
ALTER TABLE `infoRazon`
  MODIFY `idrazon` int(11) NOT NULL AUTO_INCREMENT;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `infoDoggo`
--
ALTER TABLE `infoDoggo`
  ADD CONSTRAINT `infRazon` FOREIGN KEY (`razon`) REFERENCES `infoRazon` (`idrazon`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `informacion`
--
ALTER TABLE `informacion`
  ADD CONSTRAINT `infDuenio` FOREIGN KEY (`duenio`) REFERENCES `infoDuenio` (`idinfoDuenio`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `infRaza` FOREIGN KEY (`raza`) REFERENCES `infoDoggo` (`idinfoDoggo`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
